# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '9dd305166274381ef6eabdfa7f0f875b9fb4d92c842f81529539e6195cfa868888804cde36026cf6e2ddfe3b6c1a0bcd426d5349ed237e79bbbca39dca655b14'